//
//  VKJSONOperation.h
//  VKSdk
//
//  Created by Roman Truba on 26.06.15.
//  Copyright (c) 2015 VK. All rights reserved.
//

#import "VKHTTPOperation.h"

/**
 Operation for parsing response string to JSON object, and returning JSON result
 */
@interface VKJSONOperation : VKHTTPOperation

@end
