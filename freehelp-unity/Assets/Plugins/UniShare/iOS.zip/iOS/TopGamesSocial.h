//
//  TopGamesSocial.h
//  activitysheetplugin
//
//  Created by Robert on 2014.07.25..
//  Copyright (c) 2014 Top Games. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopGamesSocial : NSObject
- (void)_presentActivitySheetWithData :(id)data;
- (void)dismissLoadingSprite;
@end
